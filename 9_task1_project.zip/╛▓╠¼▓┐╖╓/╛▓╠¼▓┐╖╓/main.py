from vision import Vision
from action import Action
from debug import Debugger
from prm import PRM
import time
from dwa import DWA
import math
import numpy as np
import RRT_TRY

# def correct_pose(pose,goal):#修正姿态朝target/goal行进
#     action = Action()
#     vision = Vision()
#     current_pose = (vision.my_robot.x,vision.my_robot.y,vision.my_robot.orientation)
#     dx = goal[0] - current_pose[0]
#     dy = goal[1] - current_pose[1] 
#     target_angel = math.atan2(dy,dx) 
#     pose_angel = current_pose[2]
#     error_angel = pose_angel - target_angel
#     if ((error_angel >= 0 and error_angel <= math.pi) or error_angel <= -math.pi):
#         action.sendCommand(vx=0, vw=2) #顺时针转
#     else:
#         action.sendCommand(vx=0, vw=2) #逆时针
    
#     while (abs(error_angel) <= 0.175 or (abs(error_angel)-2*math.pi) <= 0.175):  #正负十度
#         current_pose = (vision.my_robot.x,vision.my_robot.y,vision.my_robot.orientation) #更新角度误差
#         dx = goal[0] - current_pose[0]
#         dy = goal[1] - current_pose[1] 
#         target_angel = math.atan2(dy,dx) 
#         pose_angel = current_pose[2]
#         error_angel = pose_angel - target_angel
    
#     action.sendCommand(vx=0, vw=0)
vision = Vision()
action = Action()
dwa = DWA()
debugger = Debugger()

def from_A_to_B(pose, velocity, goal, obstacles):   #从A到B的函数，内部自带角度矫正与障碍物输入，如果角度矫正寄了的话的话可以取消？

    pose = (vision.my_robot.x, vision.my_robot.y, vision.my_robot.orientation)
    i=0
    goal_B = goal
    for i in range(8): #range指障碍物的数量，之后根据效果改变
        obstacles.insert(i, [vision.yellow_robot[i].x, vision.yellow_robot[i].y])
        # obstacles.insert(i, [vision.blue_robot[i].x, vision.blue_robot[i].y])
    '''  
    ################################################################################
    ################################################################################correct pose
    current_pose = (vision.my_robot.x,vision.my_robot.y,vision.my_robot.orientation)
    dx = goal_B[0] - current_pose[0]
    dy = goal_B[1] - current_pose[1] 
    
    target_angel = math.atan2(dy,dx) 
    pose_angel = current_pose[2]
    error_angel = pose_angel - target_angel
    if ((error_angel >= 0 and error_angel <= math.pi) or error_angel <= -math.pi):
        action.sendCommand(vx=0, vw=2) #顺时针转
    else:
        action.sendCommand(vx=0, vw=2) #逆时针
    
    
    while (abs(error_angel) >= 0.175 or (abs(error_angel)-2*math.pi) >= 0.175):  #正负十度
        current_pose = (vision.my_robot.x,vision.my_robot.y,vision.my_robot.orientation) #更新角度误差
        dx = goal_B[0] - current_pose[0]
        dy = goal_B[1] - current_pose[1] 
        target_angel = math.atan2(dy,dx) 
        pose_angel = current_pose[2]
        error_angel = pose_angel - target_angel
    
    #action.sendCommand(vx=0, vw=0)
    #################################################################################
    #################################################################################correct pose
    '''
    R_within = 10000   #distance
    b_velocity=(0.0,0.0)
    while R_within >= 100:   #目标距离
    #####action.controlObs(vision)
        j = 0
        #print("ooooooowwwwwwwwvelcityraw:",vision.my_robot.vel_x,vision.my_robot.vel_y)
        for j in range(8):
            obstacles[j] = [vision.yellow_robot[j].x, vision.yellow_robot[j].y]
        j=0
        # for j in range(8): 
            # n=j+8
            # obstacles[n] = [vision.blue_robot[j].x, vision.blue_robot[j].y]
        pose = (vision.my_robot.x, vision.my_robot.y, vision.my_robot.orientation)
        #print("wwwwwwwwwvelocity:",vision.my_robot.raw_vel_x, vision.my_robot.vel_y,"while velocity is :",velocity)
        velocity=b_velocity
        #velocity=(math.sqrt(vision.my_robot.vel_x**2+vision.my_robot.vel_y**2),0)
        b_velocity = dwa.velocity_planning(pose, velocity, goal_B, np.array(obstacles, np.float32),dwa.config)   #寻找最佳路径
        
        #print("the best velocity now is:",b_velocity)
        #pose = dwa.move(pose, velocity,dwa.config)
        action.sendCommand(vx=b_velocity[0], vy=0, vw=b_velocity[1])
        dx = pose[0] - goal_B[0]
        dy = pose[1] - goal_B[1]
        R_within = math.sqrt(dx*dx+dy*dy)
          #开跑
        #time.sleep(0.02)
        
    action.sendCommand(vx=0, vy=0, vw=0)  #停下来


def init_set():
    # vision = Vision()
    # action = Action()
    #start_x, start_y = vision.my_robot.x, vision.my_robot.y
    pose = (2400,1500,math.pi)#(vision.my_robot.x, vision.my_robot.y, vision.my_robot.orientation)
    
    
    # path_x, path_y, road_map, sample_x, sample_y = planner.plan(vision=vision, 
    #     start_x=start_x, start_y=start_y, goal_x=goal_x, goal_y=goal_y)   自带的prm代码
    # 2. send command
    # action.sendCommand(vx=0, vy=0, vw=0)   #初始000
    return pose

def main():
    planner = RRT_TRY.RRT()
    # vision = Vision()
    # action = Action()
    #debugger = Debugger()
    #planner = PRM()
    time.sleep(1)
    goal_x, goal_y = -2400, -1500
    
    start_x, start_y = vision.my_robot.x, vision.my_robot.y
    path_x, path_y= planner.plan(vision, start_x, start_y, goal_x, goal_y)
    print("xxxx",path_x)
    print("yyyy",path_y)
    debugger.draw_all_new(path_x, path_y)
    time.sleep(2)
   
    

    # while True:
        
    #     # 1. path planning & velocity planning
        
    #     goal_x, goal_y = -2400, -1500
    #     target_now = (goal_x,goal_y)
    #     obstacles = []
    #     pose = init_set()
        
    #     velocity=(0.0,0.0)
    #     print("start!")
    #     from_A_to_B(pose, velocity, target_now, obstacles)
        
    #     # path_x, path_y, road_map, sample_x, sample_y = planner.plan(vision=vision, 
    #     #     start_x=start_x, start_y=start_y, goal_x=goal_x, goal_y=goal_y)   自带的prm代码


    #     # 2. send command
    #     # action.sendCommand(vx=0, vy=0, vw=0)   #初始000

    #     # 3. draw debug msg
    #     #debugger.draw_all(sample_x, sample_y, road_map, path_x, path_y)
        
    #     time.sleep(0.1)

    #     # print(path_x)#自己加的
    #     time.sleep(10)#自己加的
        



if __name__ == '__main__':
    main()
    
