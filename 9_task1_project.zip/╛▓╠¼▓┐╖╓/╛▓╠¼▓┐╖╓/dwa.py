import numpy as np
import math
from vision import Vision
from action import Action
from debug import Debugger

debugger = Debugger()
from zss_debug_pb2 import Debug_Msgs, Debug_Msg, Debug_Arc
package = Debug_Msgs()

class Config(object):  #限制参数
    max_speed = 800   #max速度
    min_speed = -500   #倒车速度
    max_yaw = np.radians(100.0)  # max角速度
    max_accel = 3000  # max加速度
    max_dyawrate = 8  # max角加速度
    velocity_resolution = 50  # 分度
    yawrate_resolution = np.radians(5.0)  # 分度
    dt = 0.02  # dwa时间间隔
    predict_time =  0.2
    heading = 1
    clearance = 0.5
    velocity = 0.2
    robot_size = 200  #机器人尺寸,D=9;
    avoid_dist = 200

class DWA(object):

    def __init__(self):
        self.obstacles = []  # 障碍物,append
        # Planner Settings
        self.velocity = (0.0, 0.0)  # 速度 vx vw
        self.pose = (0.0, 0.0, 0.0)  # 位姿 x y celta
        self.goal = None  # 目标 (x,y)
        # 一些参数 需要设置 具体是多少还不清楚
        self.config = Config()

    def heading_evaluation(self, pose, goal,config):  #方位角？还是距离？
        dx = goal[0] - pose[0]
        dy = goal[1] - pose[1]
        distance_cost = math.sqrt(dx*dx+dy*dy)   #距离误差
        
        target_angel = math.atan2(dy,dx)/math.pi*180 
        pose_angel = pose[2]/math.pi*180  #角度制
        angel_cost = self.caculate_absolute_angel(target_angel,pose_angel,config)   #角度误差，0-180
        return angel_cost + distance_cost/100  #暂定角度？
    
    def caculate_absolute_angel(self,theta1,theta2,config):  #把-180-180转成0-360并计算绝对差
        x = (theta1 + 360) % 360
        y = (theta2 + 360) % 360
        diff = abs(x - y)
        return min(diff,360-diff)

    def velocity_evaluation(self, velocity, config):  #max_speed
        return config.max_speed - velocity[0]
    
    def move(self,pose,velocity,config):
        #v_divide_w =velocity[0]/velocity[1]
        
        w_new = pose[2]+velocity[1]*config.dt
        x_new = pose[0]+velocity[0]*math.cos(w_new)*config.dt
        y_new = pose[1]+velocity[0]*math.sin(w_new)*config.dt
        pose_new = (x_new,y_new,w_new)
        
        return pose_new
    
    def move_10dt(self,pose,velocity,config,package):
        start_time=0
        new_pose = pose    #= self.move(pose,velocity,config)
        now_pose = pose
        while start_time <= config.predict_time:
            new_pose = self.move(now_pose,velocity,config)

            debugger.draw_line(package,x1=now_pose[0],y1=now_pose[1],x2=new_pose[0],y2=new_pose[1])  #######debug

            now_pose = new_pose                       #画完线之后现在的位置变为了新位置
            start_time =start_time + config.dt

    def dist_evaluation(self, pose, velocity, obstacles,config):
        start_time=0
        MAX_COST = 100000
        min_distance_para = 100000
        new_pose = pose    #= self.move(pose,velocity,config)
        now_pose = pose
        while start_time <= config.predict_time:
            new_pose = self.move(now_pose,velocity,config)

            # debugger.draw_line(package,x1=now_pose[0],y1=now_pose[1],x2=new_pose[0],y2=new_pose[1])  #######debug

            now_pose = new_pose                       #画完线之后现在的位置变为了新位置
            for i in range(int(obstacles.size / 2) - 1):
                dx = new_pose[0] - obstacles[i][0]
                dy = new_pose[1] - obstacles[i][1]
                r = math.sqrt(dx * dx + dy * dy)
                if r <= 120:
                    return MAX_COST
                if r < min_distance_para:
                    min_distance_para = r    #小车直径为90
                i = i+1
                start_time =start_time + config.dt

        # debugger.send(package)

        if min_distance_para >= 400:      #距离大于250则障碍物耗散取0
            return 0
        dist_cost = 100000 / math.pow(min_distance_para/120,4)
        # if dist_cost <= 33:
        #     dist_cost = 0            #如果没有障碍物，那么这一项影响因数要减小
        return dist_cost
    
    def velocity_planning(self, pose, velocity, goal, obstacles,config):
        min_v = max(config.min_speed, velocity[0] - config.max_accel * config.dt)
        max_v = min(config.max_speed, velocity[0] + config.max_accel * config.dt)
        min_w = -5  #max(-config.max_yaw, velocity[1] - config.max_dyawrate * config.dt)    ####       
        max_w = 5  #min(config.max_yaw, velocity[1] + config.max_dyawrate * config.dt)   #角速度的范围

        possible_v = np.linspace(min_v, max_v, num=int((max_v - min_v) / config.velocity_resolution) + 1)
        possible_w = np.linspace(min_w, max_w, num=int((max_w - min_w) / config.yawrate_resolution) + 1)
        #print("aaaaaaaaapossible_v:",possible_v)
        best_velocity = velocity
        min_cost = float('inf')

        package = Debug_Msgs()

        for v in possible_v:
            for w in possible_w:
                p_velocity = (v, w)
                p_pose = self.move(pose, p_velocity,config)  #move多少dt？
                
                
                # debugger.draw_line(package,x1=pose[0],y1=pose[1],x2=p_pose[0],y2=p_pose[1])  #######debug
                

                cost_vel = self.velocity_evaluation(p_velocity,config)   #速度
                cost_head = self.heading_evaluation(p_pose, goal,config)   #角度，距离误差
                cost_clearance = self.dist_evaluation(pose, p_velocity, obstacles,config)   #障碍物误差
                cost = config.velocity * cost_vel + config.heading * cost_head + config.clearance * cost_clearance
                #print("vvvvvvvvvvvvvvvvvvvvv33333333333is:",cost_vel,cost_head,cost_clearance)
                if cost < min_cost:
                    min_cost = cost
                    best_velocity = p_velocity

        
        self.move_10dt(pose,best_velocity,config,package)
        debugger.draw_circle(package, pose[0], pose[1], radius=300)
        debugger.draw_point(package,goal[0],goal[1])
        debugger.send(package)  
        #print("cost:velocity,heading_evaluation,dist_evaluation",cost_vel,cost_head,cost_clearance)
        return best_velocity
    
    # def correct_pose(self,goal):#修正姿态朝target/goal行进
    #     # action = Action()
    #     # vision = Vision()
    #     current_pose = (vision.my_robot.x,vision.my_robot.y,vision.my_robot.orientation)
    #     dx = goal[0] - current_pose[0]
    #     dy = goal[1] - current_pose[1] 
    #     target_angel = math.atan2(dy,dx) 
    #     pose_angel = current_pose[2]
    #     error_angel = pose_angel - target_angel
    #     if ((error_angel >= 0 and error_angel <= math.pi) or error_angel <= -math.pi):
    #         action.sendCommand(vx=0, vw=2) #顺时针转
    #     else:
    #         action.sendCommand(vx=0, vw=2) #逆时针
        
    #     while (abs(error_angel) <= 0.175 or (abs(error_angel)-2*math.pi) <= 0.175):  #正负十度
    #         current_pose = (vision.my_robot.x,vision.my_robot.y,vision.my_robot.orientation) #更新角度误差
    #         dx = goal[0] - current_pose[0]
    #         dy = goal[1] - current_pose[1] 
    #         target_angel = math.atan2(dy,dx) 
    #         pose_angel = current_pose[2]
    #         error_angel = pose_angel - target_angel
        
    #     action.sendCommand(vx=0, vw=0)
    
    # def from_A_to_B(self, pose, velocity, goal, obstacles):   #从A到B的函数，内部自带角度矫正与障碍物输入，如果角度矫正寄了的话的话可以取消？
    #     # vision = Vision()
    #     # action = Action()
    #     pose = (vision.my_robot.x, vision.my_robot.y, vision.my_robot.orientation)
    #     i=0
    #     goal_B = goal
    #     for i in range(16): #range指障碍物的数量，之后根据效果改变
    #         obstacles.insert(i, [vision.yellow_robot[i].x, vision.yellow_robot[i].y])
    #     self.correct_pose(goal_B)  #optional
    #     R_within = 10000   #distance
        
    #     while R_within >= 100:   #目标距离
    #     #####action.controlObs(vision)
    #         j = 0
    #         for j in range(16):
    #             obstacles[j] = [vision.yellow_robot[j].x, vision.yellow_robot[j].y]
    #         pose = (vision.my_robot.x, vision.my_robot.y, vision.my_robot.orientation)
    #         velocity = self.velocity_planning(pose, velocity, goal_B, obstacles)   #寻找最佳路径
    #         pose = self.move(pose, velocity)
    #         dx = pose[0] - goal_B[0]
    #         dy = pose[1] - goal_B[1]
    #         R_within = math.sqrt[dx*dx+dy*dy]
    #         action.sendCommand(vx=velocity[0], vy=0, vw=velocity[1])  #开跑
    #     action.sendCommand(vx=0, vy=0, vw=0)  #停下来



    


        