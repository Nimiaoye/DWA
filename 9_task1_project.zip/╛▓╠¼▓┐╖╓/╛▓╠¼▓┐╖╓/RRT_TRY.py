from sys import path
from matplotlib.pyplot import step
from scipy.spatial import KDTree
import numpy as np
import random
import math
import time
class Node(object):
    def __init__(self, x, y, cost=0, parent=None, next=[]):
        self.x = x
        self.y = y
        self.cost = cost
        self.parent = parent
        self.next = next 
class RRT(object):
    
    def __init__(self, STEP=1600):
        self.minx = -4500
        self.maxx = 4500
        self.miny = -3000
        self.maxy = 3000
        self.robot_size = 150
        self.avoid_dist = 150
        self.STEP = STEP
    def plan(self, vision, start_x, start_y, goal_x, goal_y):
           # 初始化树（障碍物和路径树）和路径相关变量
        start_node, goal_node, path_x, path_y, path_dict, pathtree, obstree = self.OBSTreeinit(
            vision, start_x, start_y, goal_x, goal_y)
        for i in range(0, 5000):
            # 随机采样一个新节点
            rand_node = self.sampling(obstree)
            #找到离新节点最近的生长树上的节点
            nearest_node = self.Nearest(
                pathtree, rand_node, path_x, path_y, path_dict)
            #根据最近节点找到新节点
            new_node, nearest_node = self. new_state(
                rand_node, nearest_node, goal_node, path_x, path_y, path_dict, pathtree, obstree)
            # 检查新节点和最近节点之间的路径是否无碰撞
            if self.check_obs(new_node, nearest_node, obstree):
                #找到10个相邻节点
                NEAR_NODES = self.Near(
                    new_node, pathtree, path_dict, path_x, path_y, 10)
                # 选择成本最小的父节点
                min_node, min_cost = self.ChooseParent(
                    NEAR_NODES, nearest_node, new_node, obstree)
                # 将新节点添加到路径树中
                path_x, path_y, path_dict, pathtree = self.addNode(min_node, new_node, min_cost,
                                                                       path_x, path_y, path_dict, pathtree)
                # 检查是否到达终点
                if new_node.x == goal_x and new_node.y == goal_y:
                    goal_node = new_node
                    break
                # 根据新节点和附近节点重新连接树
                near_node, new_node = self.rewire(
                    NEAR_NODES, new_node, obstree, path_x, path_y)
                # update path_dict
                path_dict[(new_node.x, new_node.y)] = new_node
                path_dict[(near_node.x, near_node.y)] = near_node
        if i >= 4999:
           print('No path found!')
        pa_x, pa_y, patree = self.get_path_tree(goal_node)
          #简化和平滑路径
        pa_x, pa_y = self.pathnodesdelete(pa_x, pa_y, path_dict, obstree)
        pa_x, pa_y = self.pathsmooth2(pa_x, pa_y, path_dict, obstree)
        return pa_x, pa_y  

    

    def OBSTreeinit(self, vision, start_x, start_y, goal_x, goal_y):
        obstacle_x = []
        obstacle_y = []
        for robot_blue in vision.blue_robot:
            if robot_blue.visible and robot_blue.id > 0:
                obstacle_x.append(robot_blue.x)
                obstacle_y.append(robot_blue.y)
        for robot_yellow in vision.yellow_robot:
            if robot_yellow.visible:
                obstacle_x.append(robot_yellow.x)
                obstacle_y.append(robot_yellow.y)
        obstree = KDTree(np.vstack((obstacle_x, obstacle_y)).T)
        # 初始化start_node和 goal_node
        start_node = Node(start_x, start_y)
        goal_node = Node(goal_x, goal_y)
        # 生成初始的路径树
        path_x = [start_x]
        path_y = [start_y]
        pathtree = KDTree(np.vstack((path_x, path_y)).T)
        path_dict = {}
        path_dict[(start_x, start_y)] = start_node
        return start_node, goal_node, path_x, path_y, path_dict, pathtree, obstree
  
    def sampling(self,obstree):
          # 在空间中随机产生一个点xrand ->这个点不能是碰撞点
        tx = (random.random() * (self.maxx - self.minx)) + self.minx
        ty = (random.random() * (self.maxy - self.miny)) + self.miny
        distance, index = obstree.query(np.array([tx, ty]))
        t=1
        while(t):
            if distance >= self.robot_size + self.avoid_dist:
                rand_node = Node(tx,
                        ty)
                t=0
            else: #如果随机点为可能碰撞点则重新生成
                 tx = (random.random() * (self.maxx - self.minx)) + self.minx
                 ty = (random.random() * (self.maxy - self.miny)) + self.miny
                 distance, index = obstree.query(np.array([tx, ty]))
        return rand_node

    def Nearest(self, pathtree, rand_node, path_x, path_y, path_dict):
        # 在已知树的点集合中找到距离这个随机点最近的点xnearest
        distance, index = pathtree.query(np.array([rand_node.x, rand_node.y]))
        nearest_node = path_dict[(path_x[index], path_y[index])]
        return nearest_node

    def new_state(self, rand_node, nearest_node, goal_node, path_x, path_y, path_dict, pathtree, obstree):
        #. 扩展树：从树T中找到最近的节点x_near，以x_near为起点，在方向上延伸一定的距离，得到新的节点x_new
        nx = rand_node.x - nearest_node.x
        ny = rand_node.y - nearest_node.y
        distance_to_rand = math.sqrt(nx**2 + ny**2) #计算随机点和距离最近点之间的距离
        '''
        if distance_to_rand <= self.STEP and  self.check_obs(rand_node,nearest_node, obstree):
            new_node=rand_node
        else:
        '''
        #上面这段注释掉的代码适用于快速拓展RRT树，但效果不好
        angle = math.atan2(ny,nx)
        new_node = Node(math.cos(angle) * self.STEP + nearest_node.x,
                        math.sin(angle) * self.STEP + nearest_node.y) 
        if len(path_x) > 1:
            # 如果检测到目标在step内则直接将目标点作为新节点
            distance, index = pathtree.query(
                np.array([goal_node.x, goal_node.y]), min(len(path_x), 4))
            for (distance1, index1) in zip(distance, index):
                if distance1 < self.STEP and self.check_obs(goal_node, path_dict[(path_x[index1], path_y[index1])], obstree):
                    new_node.x = goal_node.x
                    new_node.y = goal_node.y
                    nearest_x = path_x[index1]
                    nearest_y = path_y[index1]
                    nearest_node = path_dict[(nearest_x, nearest_y)]
                    break
        return new_node, nearest_node

    def check_obs(self,new_node, nearest_node, obstree):
        #碰撞检测
        dx = nearest_node.x - new_node.x
        dy = nearest_node.y - new_node.y
        angle = math.atan2(dy, dx)
        dis = math.hypot(dx, dy)
        nx=new_node.x
        ny = new_node.y
        step_size = self.robot_size + self.avoid_dist
        steps = round(dis/step_size)
        for i in range(steps):
            distance, index = obstree.query(np.array([nx, ny]))
            if distance <= self.robot_size + self.avoid_dist:
                return False
            nx += step_size * math.cos(angle)
            ny += step_size * math.sin(angle)
        return True

       
    def Near(self, new_node, pathtree, path_dict, path_x, path_y, n):
        #找到n个临近节点
        NEAR_NODES = []
        distance, index = pathtree.query(
            np.array([new_node.x, new_node.y]), min([len(path_x), n]))
       # 检查返回的是否是单个节点
        if type(distance) != np.ndarray:
            distance = [distance]
            index = [index]
        # 将找到的临近节点添加到NEAR_NODES列表中
        for i in index:
            temp_node = path_dict[(path_x[i], path_y[i])]
            NEAR_NODES.append(temp_node)
        return NEAR_NODES
    def calculate_cost(self,nearest_node,new_node):
        #计算路径消耗
        mini_cost=nearest_node.cost + \
        math.hypot(new_node.x - nearest_node.x, 
                   new_node.y - nearest_node.y)
        return mini_cost
 
    def ChooseParent(self, NEAR_NODES, nearest_node, new_node, obstree):
      #计算路径损耗，确定损耗最小的min_node以及对应的 min_cost
        min_node = nearest_node
        min_cost= self.calculate_cost(nearest_node, new_node)
        for near_node in NEAR_NODES:
            cost = self.calculate_cost(nearest_node, new_node)
            if self.check_obs(new_node, near_node, obstree) and cost < min_cost:
                min_node = near_node
                min_cost = cost
        return min_node, min_cost

    def addNode(self, min_node, new_node, min_cost, path_x, path_y, path_dict, pathtree):
         #将min_node和new_node添加到路径树中同时 update path_dict
        new_node.cost = min_cost
        new_node.parent = min_node
        min_node.next.extend([new_node])
        new_node.next = []
        path_dict[(new_node.x, new_node.y)] = new_node
        path_dict[(min_node.x, min_node.y)] = min_node
        path_x.append(new_node.x)
        path_x.append(min_node.x)
        path_y.append(new_node.y)
        path_y.append(min_node.y)
        pathtree = KDTree(np.vstack((path_x, path_y)).T)
        return path_x, path_y, path_dict, pathtree
    def rewire(self, NEAR_NODES, new_node, obstree, path_x, path_y):
        '''Rewire the path'''
        for near_node in NEAR_NODES:
            cost = self.calculate_cost(near_node, new_node)
            if self.check_obs(new_node, near_node, obstree) and cost < near_node.cost:
                near_node.parent = new_node
                near_node.cost = self.calculate_cost(near_node, new_node)
                new_node.next.append(near_node)
        return near_node, new_node

    def get_path_tree(self, goal_node):
        pathtree_node = goal_node
        path_x = []
        path_y = []
        while pathtree_node.parent != None and pathtree_node.parent != 0:
            path_x.insert(0, pathtree_node.x)  
            path_y.insert(0, pathtree_node.y)
            pathtree_node =pathtree_node.parent
        path_x.insert(0, pathtree_node.x)
        path_y.insert(0, pathtree_node.y)
        pathtree = KDTree(np.vstack((path_x, path_y)).T)
        return path_x, path_y, pathtree
    
    def pathnodesdelete(self, path_x, path_y, path_dict, obstree):
        #删除没必要的节点
        while True:
            flag = True
            for i in range(0, len(path_x)-2):
                if self.check_obs(path_dict[(path_x[i], path_y[i])], path_dict[(path_x[i+2], path_y[i+2])], obstree):
                    del path_x[i+1], path_y[i+1]
                    # print('del')
                    flag = False
                    break
            if flag:
                break
        return path_x, path_y
    def pathsmooth2(self, path_x, path_y, path_dict, obstree):
     #进一步删除节点，简化路径
        new_path_x = []
        new_path_y = []

        for i in range(len(path_x)):
           if i == 0 or i == len(path_x)-1:
            new_path_x.append(path_x[i])
            new_path_y.append(path_y[i])
           else:
            if not self.check_obs(path_dict[(path_x[i-1], path_y[i-1])], path_dict[(path_x[i+1], path_y[i+1])], obstree):
                new_path_x.append(path_x[i])
                new_path_y.append(path_y[i])
        return new_path_x, new_path_y
    